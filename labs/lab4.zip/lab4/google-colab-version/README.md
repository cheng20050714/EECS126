Instructions:
1. From Google Workspace Marketplace (https://workspace.google.com/marketplace), find and install Colaboratory.
2. Go to your Google Drive. On the left panel, click on My Drive.
3. Right click on the empty space in your Drive and select Folder upload, then upload the wordle-colab folder.
4. Double click the wordle-colab folder that you have just uploaded.
5. Right click on wordle.ipynb and select Open with, then select Google Colaboratory.
